#include <stdio.h>
int main() {
    int start, end;
    printf("Enter the starting number of the range: ");
    scanf("%d", &start);
    printf("Enter the ending number of the range: ");
    scanf("%d", &end);
    printf("Range is from %d to %d\n", start, end);
    return 0;
}