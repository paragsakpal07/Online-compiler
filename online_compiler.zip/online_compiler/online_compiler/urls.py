from django.contrib import admin
from django.urls import path
from compapp.views import home, index, java, c, javascript

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name="home"),
    path('python', index ,name="python_compiler"),
    path('java', java, name="java_compiler"),
    path('c', c, name="c_compiler"),
    path('javascript', javascript, name="javascript_compiler")
]
