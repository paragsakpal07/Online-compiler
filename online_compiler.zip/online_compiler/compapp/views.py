from django.shortcuts import render
from django.http import JsonResponse
import subprocess, sys, tempfile, os, platform, uuid, re, requests

def home(request):
    return render(request, "compapp/home.html")

import os
import sys
import tempfile
import subprocess
from django.shortcuts import render

def index(request):
    default_code = "print('Hello, World!')"
    code = default_code
    output = ""
    user_input = ""

    if request.method == "POST":
        if "clear" in request.POST:
            code, output, user_input = default_code, "", ""
            request.session["stdin_history"] = ""
            request.session["stdout_history"] = ""
        else:
            # ✅ Get code & new input
            code = request.POST.get("code", "")
            new_input = request.POST.get("stdin", "").strip()

            # ✅ Restore history
            previous_input = request.session.get("stdin_history", "")
            previous_output = request.session.get("stdout_history", "")

            # ✅ Append new input to history
            if new_input:
                user_input = previous_input + new_input + "\n"
            else:
                user_input = previous_input

            request.session["stdin_history"] = user_input

            temp_file_path = None
            try:
                with tempfile.NamedTemporaryFile(delete=False, suffix=".py") as temp_file:
                    temp_file.write(code.encode("utf-8"))
                    temp_file_path = temp_file.name

                # ✅ Run with accumulated inputs
                process = subprocess.run(
                    [sys.executable, temp_file_path],
                    input=user_input,
                    capture_output=True,
                    text=True,
                    timeout=5
                )

                # ✅ Program output
                program_output = process.stdout if process.stdout else process.stderr
                program_output = program_output.replace(": ", ":\n")

                # ✅ Only append the **new output** for this run
                if new_input:
                    combined_output = f">>> {new_input}\n{program_output}".strip()
                else:
                    combined_output = program_output.strip()

                output = combined_output

                # Save updated output history (if you still want to track it)
                request.session["stdout_history"] = output

            except subprocess.TimeoutExpired:
                output = "Error: Program took too long or is waiting for more input."
            except Exception as e:
                output = f"Error while running Python code: {e}"
            finally:
                if temp_file_path and os.path.exists(temp_file_path):
                    os.remove(temp_file_path)

            # ✅ Always clear input box
            user_input = ""

    else:
        request.session["stdin_history"] = ""
        request.session["stdout_history"] = ""

    return render(
        request,
        "compapp/index.html",
        {"code": code, "output": output, "stdin": user_input},
    )


# -------------------------
# Java Compiler
# -------------------------


import re
import requests
from django.shortcuts import render

def java(request):
    default_code = """public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}"""
    code = default_code
    output = []
    user_input = ""

    if request.method == "POST":
        if "clear" in request.POST:
            code, output, user_input = default_code, [], ""
        else:
            code = request.POST.get("code", "")
            user_input = request.POST.get("stdin", "").strip()

            # ✅ Ensure class name is always Main
            code_fixed = re.sub(r"public\s+class\s+\w+", "public class Main", code)

            # ✅ Format user input (newline separated)
            formatted_input = user_input.replace(" ", "\n")

            try:
                # 🔹 Send code to Piston API
                response = requests.post(
                    "https://emkc.org/api/v2/piston/execute",
                    json={
                        "language": "java",
                        "version": "15.0.2",
                        "files": [{"name": "Main.java", "content": code_fixed}],
                        "stdin": formatted_input,
                    },
                    timeout=10
                )

                if response.status_code == 200:
                    result = response.json()

                    # Get only the latest run output (no accumulation)
                    run_output = result.get("run", {}).get("output", "")
                    cleaned_output = run_output.replace("\r", "").replace("\t", "    ")
                    output = cleaned_output.strip().split("\n") if cleaned_output.strip() else []
                else:
                    output = [f"API Error: {response.status_code}"]

            except requests.exceptions.Timeout:
                output = ["Error: API request timed out."]
            except Exception as e:
                output = [f"Error while running Java code via API: {e}"]

    return render(request, "compapp/java.html", {
        "code": code,
        "output": output,
        "stdin": user_input,
    })






def c(request):
    default_code = """#include <stdio.h>

int main() {
    printf("Hello, World!\\n");
    return 0;
}
"""
    code = default_code
    output = []
    user_input = ""

    if request.method == "POST":
        if "clear" in request.POST:
            code, output, user_input = default_code, [], ""
        else:
            code = request.POST.get("code", "")
            user_input = request.POST.get("stdin", "").strip()

            # ✅ Format user input (newline separated)
            formatted_input = user_input.replace(" ", "\n")

            try:
                # 🔹 Send code to Piston API
                response = requests.post(
                    "https://emkc.org/api/v2/piston/execute",
                    json={
                        "language": "c",
                        "version": "10.2.0",  # GCC version in Piston
                        "files": [{"name": "main.c", "content": code}],
                        "stdin": formatted_input,
                    },
                    timeout=10
                )

                if response.status_code == 200:
                    result = response.json()

                    # Get only the latest run output (no accumulation)
                    run_output = result.get("run", {}).get("output", "")
                    cleaned_output = run_output.replace("\r", "").replace("\t", "    ")
                    output = cleaned_output.strip().split("\n") if cleaned_output.strip() else []
                else:
                    output = [f"API Error: {response.status_code}"]

            except requests.exceptions.Timeout:
                output = ["Error: API request timed out."]
            except Exception as e:
                output = [f"Error while running C code via API: {e}"]

    return render(request, "compapp/c.html", {
        "code": code,
        "output": output,
        "stdin": user_input,
    })




# -------------------------
# JavaScript Compiler
# -------------------------

def preprocess_js_code(user_code: str) -> str:
    """
    Convert browser-like prompt() calls into Node.js stdin-based input.
    Ensures input is echoed on the same line as the prompt.
    """
    if "prompt(" not in user_code:
        return user_code  # nothing to replace

    wrapper = """
const fs = require("fs");
const input = fs.readFileSync(0, "utf-8").trim().split(/\\r?\\n/);
let inputIndex = 0;
function prompt(question) {
    if (question) process.stdout.write(question + " ");  // show question without newline
    const ans = inputIndex < input.length ? input[inputIndex++].trim() : "";
    console.log(ans);  // echo user input on SAME line
    return ans;
}
"""
    return wrapper + "\n" + user_code



def javascript(request):
    code = request.POST.get("code", 'console.log("Hello, World!");')
    stdin_data = request.POST.get("stdin", "")
    output = ""
    html_preview = None  # <--- for browser-based code

    if "run" in request.POST:
        try:
            stripped = code.strip()

            # ✅ If it starts with HTML tags OR contains <script> or <input>, preview instead of Node.js
            if stripped.startswith("<") or "<script" in stripped or "<input" in stripped or "<button" in stripped:
                html_preview = code
                output = "[HTML Preview Mode: See rendered output below]"

            else:
                # ✅ Normal Node.js execution
                processed_code = preprocess_js_code(code)

                with tempfile.NamedTemporaryFile(delete=False, suffix=".js", mode="w", encoding="utf-8") as temp_file:
                    temp_file.write(processed_code)
                    temp_path = temp_file.name

                result = subprocess.run(
                    ["node", temp_path],
                    input=stdin_data,
                    text=True,
                    capture_output=True,
                    timeout=10
                )
                output = result.stdout + result.stderr

        except subprocess.TimeoutExpired:
            output = "⏱ Execution timed out."
        except Exception as e:
            output = f"❌ Error: {str(e)}"
        finally:
            if "temp_path" in locals() and os.path.exists(temp_path):
                os.remove(temp_path)

    elif "clear" in request.POST:
        code = 'console.log("Hello, World!");'
        stdin_data = ""
        output = ""
        html_preview = None

    return render(request, "compapp/javascript.html", {
        "code": code,
        "stdin": stdin_data,
        "output": output,
        "html_preview": html_preview,  # ✅ send preview safely
    })
